import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from datasets import load_dataset
from torchvision.transforms import functional as F
from tqdm import tqdm

# ✅ Device setup
device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
print(f"✅ Using device: {device}")

# ✅ Image transforms
from torchvision.transforms import functional as F
from PIL import Image

# Custom transform wrapper
class EnsureRGB:
    def __call__(self, img):
        if img.mode != "RGB":
            img = img.convert("RGB")
        return img

transform = transforms.Compose([
    EnsureRGB(),  # 🔥 force 3-channel RGB
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
])


# ✅ Dataset wrapper
class HFDatasetWrapper(Dataset):
    def __init__(self, hf_dataset, transform):
        self.data = hf_dataset
        self.transform = transform

        # Build label mapping if needed
        labels = list(set(example["label"] for example in self.data))
        self.label_to_index = {label: idx for idx, label in enumerate(sorted(labels))}

    def __getitem__(self, idx):
        sample = self.data[idx]
        image = self.transform(sample["image"])

        label = sample["label"]
        # Convert string labels to index
        if isinstance(label, str):
            label = self.label_to_index[label]

        label = torch.tensor(label, dtype=torch.long)
        return image, label

    def __len__(self):
        return len(self.data)


# ✅ DataLoader factory
def make_loaders(hf_dataset):
    return (
        DataLoader(HFDatasetWrapper(hf_dataset["train"], transform), batch_size=32, shuffle=True),
        DataLoader(HFDatasetWrapper(hf_dataset["test"], transform), batch_size=32)
    )

# ✅ CNN Model
class SimpleCNN(nn.Module):
    def __init__(self, num_classes=30):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, padding=1), nn.ReLU(), nn.MaxPool2d(2),  # 112x112
            nn.Conv2d(32, 64, kernel_size=3, padding=1), nn.ReLU(), nn.MaxPool2d(2),  # 56x56
            nn.Conv2d(64, 128, kernel_size=3, padding=1), nn.ReLU(), nn.MaxPool2d(2), # 28x28
            nn.AdaptiveAvgPool2d((1, 1))  # Output: (128, 1, 1)
        )

        self.classifier = nn.Sequential(
            nn.Flatten(),              # (128,)
            nn.Linear(128, 64), nn.ReLU(),
            nn.Linear(64, num_classes)
        )

    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x

