import torch
import flwr as fl
from flwr.server.strategy import FedAvg
from model import SimpleCNN

# Global variable to store final parameters
final_parameters = None

# ✅ Custom FedAvg strategy that intercepts final parameters
class SaveFinalModelFedAvg(FedAvg):
    def aggregate_fit(self, rnd, results, failures):
        global final_parameters
        aggregated_result, _ = super().aggregate_fit(rnd, results, failures)
        if aggregated_result is not None:
            final_parameters = aggregated_result
        return aggregated_result, {}

# ✅ Start server with custom strategy
strategy = SaveFinalModelFedAvg()
fl.server.start_server(
    server_address="localhost:9091",
    config=fl.server.ServerConfig(num_rounds=20),
    strategy=strategy,
)

# ✅ Save model after training finishes
from flwr.common import parameters_to_ndarrays

# ✅ Save model after training finishes
if final_parameters is not None:
    print("💾 Saving final global model...")
    model = SimpleCNN(num_classes=30)
    weights = parameters_to_ndarrays(final_parameters)  # 🔥 Convert Parameters
    params_dict = zip(model.state_dict().keys(), weights)
    state_dict = {k: torch.tensor(v) for k, v in params_dict}
    model.load_state_dict(state_dict, strict=True)
    torch.save(model.state_dict(), "global_model.pth")
    print("✅ Final model saved as 'global_model.pth'")
else:
    print("⚠️ No parameters found. Model was not saved.")
