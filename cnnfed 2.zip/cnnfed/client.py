import flwr as fl
import torch
import torch.nn as nn
from model import SimpleCNN, make_loaders, device
from datasets import load_from_disk
from tqdm import tqdm
import sys

# Read client ID from command line argument
cid = int(sys.argv[1])

# Local dataset paths (must exist)
hf_datasets = [
    "client1_dataset",
    "client2_dataset",
    "client3_dataset",
    "client4_dataset",
    "client5_dataset",
]

# Load client-specific local dataset
dataset = load_from_disk(hf_datasets[cid])
train_loader, test_loader = make_loaders(dataset)

# Flower client definition
class FlowerClient(fl.client.NumPyClient):
    def __init__(self, model):
        self.model = model.to(device)

    def get_parameters(self, config):
        return [val.cpu().numpy() for val in self.model.state_dict().values()]

    def set_parameters(self, parameters):
        keys = list(self.model.state_dict().keys())
        state_dict = {k: torch.tensor(v).to(device) for k, v in zip(keys, parameters)}
        self.model.load_state_dict(state_dict, strict=True)

    def fit(self, parameters, config):
        self.set_parameters(parameters)
        self.model.train()
        optimizer = torch.optim.SGD(self.model.parameters(), lr=0.01)
        criterion = nn.CrossEntropyLoss()

        for _ in range(1):  # 1 local epoch
            for x, y in tqdm(train_loader, leave=False):
                x = x.to(device)
                y = y.to(device)
                optimizer.zero_grad()
                output = self.model(x)
                loss = criterion(output, y)
                loss.backward()
                optimizer.step()

        return self.get_parameters({}), len(train_loader.dataset), {}

    def evaluate(self, parameters, config):
        self.set_parameters(parameters)
        self.model.eval()
        criterion = torch.nn.CrossEntropyLoss()
        loss, correct, total = 0.0, 0, 0

        with torch.no_grad():
            for x, y in test_loader:
                x, y = x.to(device), y.to(device)
                output = self.model(x)
                loss += criterion(output, y).item()
                correct += (output.argmax(1) == y).sum().item()
                total += y.size(0)

        accuracy = correct / total
        print(f"✅ [Client {cid}] Accuracy: {accuracy:.4f} | Loss: {loss / len(test_loader):.4f}")  # <-- Add this line
        return loss, total, {"accuracy": accuracy}


# Create model and launch Flower client
model = SimpleCNN(num_classes=30)
fl.client.start_numpy_client(server_address="localhost:9091", client=FlowerClient(model))
