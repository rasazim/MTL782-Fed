import torch
import torch.nn as nn
from torch.utils.data import DataLoader, ConcatDataset
from datasets import load_from_disk
from model import SimpleCNN, HFDatasetWrapper, transform, device
from tqdm import tqdm

# ✅ Load and merge all 5 client training datasets
client_paths = [
    "client1_dataset",
    "client2_dataset",
    "client3_dataset",
    "client4_dataset",
    "client5_dataset",
]

train_datasets = []
for path in client_paths:
    dataset = load_from_disk(path)["train"]
    train_datasets.append(HFDatasetWrapper(dataset, transform))

# ✅ Combine into one large training dataset
merged_train_dataset = ConcatDataset(train_datasets)
train_loader = DataLoader(merged_train_dataset, batch_size=32, shuffle=True)

# ✅ Load central test set
test_dataset = load_from_disk("test_dataset_dataset")["train"]
test_loader = DataLoader(HFDatasetWrapper(test_dataset, transform), batch_size=32)

# ✅ Model setup
model = SimpleCNN(num_classes=30).to(device)
optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
criterion = nn.CrossEntropyLoss()

# ✅ Training (3 epochs for better learning)
print("🚀 Training on centralized merged data...")
for epoch in range(3):
    model.train()
    total_loss = 0
    for x, y in tqdm(train_loader, desc=f"Epoch {epoch+1}"):
        x, y = x.to(device), y.to(device)
        optimizer.zero_grad()
        output = model(x)
        loss = criterion(output, y)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    print(f"✅ Epoch {epoch+1} Loss: {total_loss / len(train_loader):.4f}")

# ✅ Save centrally trained model
torch.save(model.state_dict(), "central_model.pth")
print("✅ Central model saved as 'central_model.pth'")

# ✅ Evaluate
model.eval()
correct, total, total_loss = 0, 0, 0.0
with torch.no_grad():
    for x, y in tqdm(test_loader, desc="🔍 Evaluating Central Model"):
        x, y = x.to(device), y.to(device)
        preds = model(x)
        loss = criterion(preds, y)
        total_loss += loss.item()
        correct += (preds.argmax(1) == y).sum().item()
        total += y.size(0)

acc = correct / total
print(f"🎯 Centralized Accuracy: {acc:.4f} | Loss: {total_loss / len(test_loader):.4f}")
