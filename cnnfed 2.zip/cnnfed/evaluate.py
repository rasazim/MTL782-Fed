from model import SimpleCNN, HFDatasetWrapper, transform, device
import torch
from datasets import load_from_disk
from torch.utils.data import DataLoader
from tqdm import tqdm

# Load central test dataset
central_test_ds = load_from_disk("test_dataset_dataset")['train']
test_loader = DataLoader(HFDatasetWrapper(central_test_ds, transform), batch_size=32)

# ✅ Load trained model
model = SimpleCNN(num_classes=30).to(device)
model.load_state_dict(torch.load("global_model.pth", map_location=device))
model.eval()

# Evaluate
criterion = torch.nn.CrossEntropyLoss()
correct, total, total_loss = 0, 0, 0.0
with torch.no_grad():
    for x, y in tqdm(test_loader, desc="🔍 Evaluating"):
        x, y = x.to(device), y.to(device)
        preds = model(x)
        loss = criterion(preds, y)
        total_loss += loss.item()
        correct += (preds.argmax(1) == y).sum().item()
        total += y.size(0)

accuracy = correct / total
print(f"✅ Central Test Accuracy: {accuracy:.4f}, Loss: {total_loss / len(test_loader):.4f}")
